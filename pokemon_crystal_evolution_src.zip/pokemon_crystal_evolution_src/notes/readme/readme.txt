Controls
---------------
Arrow Keys= move
Z = jump
A = shoot
Esc = exit
F2 = restart game
Enter = exit level/ pause

How to play:
------------------
When you start, choose 1 of the 3 boxes. You can change what you picked by going into the middle square. Then choose a level to the left. Some pokemon can't go to some levels and it will tell you when. Each Pokemon has a level that it is best at. When you beat a level, the pokemon of that element evolves. Then you go back to the main area. To use the evolved pokemon, pick it's box. Try to beat all 3 levels.

Wall Jump:
---------------
On the ground level, you have to wall jump. to do this, jump and move into the wall. keep holding the arrow key. release the arrow key and quickly press jump. 
